import requests
import argis_pb2
import re
import csv

def get_binary(offset, count):
    url = "https://services5.arcgis.com/7nsPwEMP38bSkCjy/ArcGIS/rest/services/LA_Post_outbreak_mobility_data" \
          "/FeatureServer/0/query?f=pbf&where=1%3D1&returnGeometry=false&spatialRel=esriSpatialRelIntersects" \
          "&outFields=*&orderByFields=ObjectId%20ASC&outSR=102100&resultOffset={}&resultRecordCount={}&cacheHint=true" \
          "&quantizationParameters=%7B%22mode%22%3A%22edit%22%7D".format(offset, count)
    data = requests.get(url)
    return data.content


def get_object(bin_str):
    address_book = argis_pb2.TT()
    address_book.ParseFromString(bin_str)
    return address_book.ins.dsfsdd.d


def resolve_data(data):
    info = []
    res = re.findall(r'(?<=: )(.*?)(?=\n(,|]))', str(data))
    for i in res:
        data = eval(i[0])
        if type(data) == str and '""' in data:
            data = data.replace('""', '"')
        info.append(data)
    return info


if __name__ == '__main__':
    with open("2.csv", "w", encoding="utf-8") as f:
        writer = csv.writer(f)
        i = 0
        while True:
            geoinfo = []
            data = get_object(get_binary(i, 2000))
            for d in data:
                info = resolve_data(d.r)
                geoinfo.append(info)
            writer.writerows(geoinfo)
            if geoinfo[-1][-1] == 26143:
                break
            i += 2000